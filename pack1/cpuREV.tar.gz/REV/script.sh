


cp /Users/cpf/Repos/adaptive_LBM/build_LBM/example/Sph1896/* /Users/cpf/Repos/master_LBM/build_LBM/example/Sph1896/

cd /Users/cpf/Repos/master_LBM/build_LBM/example/Sph1896



cd /Users/cpf/Repos/legacy_LBM/build_LBM/example/Sph1896



cd /Users/cpf/Repos/legacy_LBM/build_LBM/example/Sph1896



cd /Users/cpf/Repos/legacy_LBM/build_LBM/example/Sph1896


cd /Users/cpf/Repos/legacy_LBM/build_LBM/example/Sph1896
